# WebComputing-Project

ANTONIO MUTO: 
Casi d'uso: gestione profilo utente, Assistenza/aiuto/ contattaci.
Schermata Login. Schermata Sign Up Il mio account.


Francesco Reda:
Casi d'uso: Restituzione articoli lato cliente , inserimento/modifica/eliminazione prodotti da parte dell'admin
